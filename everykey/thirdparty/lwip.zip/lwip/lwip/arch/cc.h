#ifndef __ARCH_CC_H__
#define __ARCH_CC_H__

// Includes definition of mch_printf macro to do printf
//#include "mch.h"

#define BYTE_ORDER  BIG_ENDIAN

typedef unsigned char     u8_t;
typedef char      s8_t;
typedef unsigned short    u16_t;
typedef short     s16_t;
typedef unsigned long    u32_t;
typedef long     s32_t;

typedef unsigned long   mem_ptr_t;

#define LWIP_ERR_T  int

/* Define (sn)printf formatters for these lwIP types */
#define U16_F "hu"
#define S16_F "hd"
#define X16_F "hx"
#define U32_F "u"
#define S32_F "d"
#define X32_F "x"

/* Compiler hints for packing structures */
#define PACK_STRUCT_FIELD(x)    x
#define PACK_STRUCT_STRUCT  __attribute__((packed))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT_END

/* Plaform specific diagnostic output */
#define LWIP_PLATFORM_DIAG(x) {}

/*
 do {                \
        mch_printf x;                   \
    } while (0)
*/

#define LWIP_PLATFORM_ASSERT(x) {}
/*
 do {                \
        mch_printf("Assert \"%s\" failed at line %d in %s\n",   \
                x, __LINE__, __FILE__);             \
        mch_abort();                        \
    } while (0)
*/

#endif /* __ARCH_CC_H__ */